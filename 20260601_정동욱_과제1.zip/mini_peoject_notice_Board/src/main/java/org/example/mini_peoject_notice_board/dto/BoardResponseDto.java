package org.example.mini_peoject_notice_board.dto;

import lombok.Builder;
import lombok.Data;
import org.example.mini_peoject_notice_board.domain.Board;

import java.time.format.DateTimeFormatter;

@Data
@Builder
public class BoardResponseDto {

    private Long id;
    private String name;
    private String title;
    private String content;
    private String createdAt;
    private String updatedAt;
    private int viewCount;

    // 목록용 - yyyy/MM/dd
    public static BoardResponseDto from(Board board) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");

        // 💡 null 체크 안전장치 추가
        String createdAtStr = board.getCreatedAt() != null ? board.getCreatedAt().format(formatter) : "";
        String updatedAtStr = board.getUpdatedAt() != null ? board.getUpdatedAt().format(formatter) : "";

        return BoardResponseDto.builder()
                .id(board.getId())
                .name(board.getName())
                .title(board.getTitle())
                .content(board.getContent())
                .createdAt(createdAtStr)
                .updatedAt(updatedAtStr)
                .viewCount(board.getViewCount())
                .build();
    }

    // 상세용 - yyyy/MM/dd HH:mm
    public static BoardResponseDto fromDetail(Board board) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm");

        // 💡 null 체크 안전장치 추가
        String createdAtStr = board.getCreatedAt() != null ? board.getCreatedAt().format(formatter) : "";
        String updatedAtStr = board.getUpdatedAt() != null ? board.getUpdatedAt().format(formatter) : "";

        return BoardResponseDto.builder()
                .id(board.getId())
                .name(board.getName())
                .title(board.getTitle())
                .content(board.getContent())
                .createdAt(createdAtStr)
                .updatedAt(updatedAtStr)
                .viewCount(board.getViewCount())
                .build();
    }
}